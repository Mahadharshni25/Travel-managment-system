import { Component } from '@angular/core';

@Component({
  selector: 'app-car-offer',
  templateUrl: './car-offer.component.html',
  styleUrl: './car-offer.component.css'
})
export class CarOfferComponent {

}
